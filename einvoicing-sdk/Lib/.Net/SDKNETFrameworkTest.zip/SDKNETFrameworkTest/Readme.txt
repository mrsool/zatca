﻿To use the code you need to 
1. reference .Net SDK DLL
2. fill the correct values in Data folder 
3. create sample xml invoice and use it in the command line tool

Sample data has been added to the certificate/ pih/ privateKey files.

To create private key you must use openssl command.
